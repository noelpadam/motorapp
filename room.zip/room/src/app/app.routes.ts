import { Routes } from '@angular/router';
import { WebglViewerComponent } from './room-scene/webgl-viewer.component';

export const routes: Routes = [
     { path: '', component: WebglViewerComponent },
];
